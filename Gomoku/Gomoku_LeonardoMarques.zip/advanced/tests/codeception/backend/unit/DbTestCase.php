<?php

namespace tests\codeception\backend\unit;

class DbTestCase extends \yii\codeception\DbTestCase
{
    public $appConfig = '@tests/codeception/config/backend/unit.php';
}
